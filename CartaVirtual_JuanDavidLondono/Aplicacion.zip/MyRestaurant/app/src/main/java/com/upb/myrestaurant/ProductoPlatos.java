package com.upb.myrestaurant;

import android.app.ListActivity;
import android.content.Context;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Objects;


public class ProductoPlatos extends ListActivity {

    public class Producto {

        private String nombreProducto;
        private String ingredientesProductos;
        private String precioProducto;
        private Integer imagenProducto;

    }

    private ProductoPlatos.MyAdapter adaptador = null;
    private static ArrayList <ProductoPlatos.Producto> arregloProductos = new ArrayList<ProductoPlatos.Producto>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        adaptador = new ProductoPlatos.MyAdapter(this);
        setData();
        setListAdapter(adaptador);
    }

    private void setData() {
        arregloProductos.clear();

        // Platos Fuertes 1
        ProductoPlatos.Producto productoActual1 = new ProductoPlatos.Producto();
        productoActual1.nombreProducto = this.getResources().getString(R.string.plato1);
        productoActual1.ingredientesProductos = this.getResources().getString(R.string.ing_plato1);
        productoActual1.precioProducto = this.getResources().getString(R.string.prec_plato1);
        productoActual1.imagenProducto = R.drawable.carne;
        arregloProductos.add(productoActual1);

        // Platos Fuertes 2
        ProductoPlatos.Producto productoActual2 = new ProductoPlatos.Producto();
        productoActual2.nombreProducto = this.getResources().getString(R.string.plato2);
        productoActual2.ingredientesProductos = this.getResources().getString(R.string.ing_plato2);
        productoActual2.precioProducto = this.getResources().getString(R.string.prec_plato2);
        productoActual2.imagenProducto = R.drawable.pollo;
        arregloProductos.add(productoActual2);

        // Platos Fuertes 3
        ProductoPlatos.Producto productoActual3 = new ProductoPlatos.Producto();
        productoActual3.nombreProducto = this.getResources().getString(R.string.plato3);
        productoActual3.ingredientesProductos = this.getResources().getString(R.string.ing_plato3);
        productoActual3.precioProducto = this.getResources().getString(R.string.prec_plato3);
        productoActual3.imagenProducto = R.drawable.chi;
        arregloProductos.add(productoActual3);
    }

    public static class MyAdapter extends BaseAdapter {

        private Context myContexto;

        public MyAdapter (Context c){
            myContexto = c;
        }

        @Override
        public int getCount() {
            return arregloProductos.size();
        }

        @Override
        public Object getItem (int position) {
            return arregloProductos.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view;

            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) myContexto.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.activity_platos, null);
            } else {
                view = convertView;
            }

            TextView nombreProducto = view.findViewById(R.id.textViewnplato);
            nombreProducto.setText(arregloProductos.get(position).nombreProducto);

            TextView ingredientesProducto = view.findViewById(R.id.textViewiplato);
            ingredientesProducto.setText(arregloProductos.get(position).ingredientesProductos);
            ImageView ingProducto = (ImageView) view.findViewById(R.id.imageViewPlatos);
            ingProducto.setImageDrawable(myContexto.getResources().getDrawable(arregloProductos.get(position).imagenProducto));


            TextView preciosProducto = view.findViewById(R.id.textViewpplato);
            preciosProducto.setText(arregloProductos.get(position).precioProducto);

            return view;
        }
    }
}

