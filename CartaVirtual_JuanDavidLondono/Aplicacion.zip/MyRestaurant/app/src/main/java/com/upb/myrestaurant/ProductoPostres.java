package com.upb.myrestaurant;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Context;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Objects;

public class ProductoPostres extends ListActivity {

    public class Producto {

        private String nombreProducto;
        private String ingredientesProductos;
        private String precioProducto;
        private Integer imagenProducto;

    }

    private ProductoPostres.MyAdapter adaptador = null;
    private static ArrayList<ProductoPostres.Producto> arregloProductos = new ArrayList<ProductoPostres.Producto>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        adaptador = new ProductoPostres.MyAdapter(this);
        setData();
        setListAdapter(adaptador);
    }

    private void setData() {
        arregloProductos.clear();

        //Postre 1
        ProductoPostres.Producto productoActual1 = new ProductoPostres.Producto();
        productoActual1.nombreProducto = this.getResources().getString(R.string.postre1);
        productoActual1.ingredientesProductos = this.getResources().getString(R.string.ing_postre1);
        productoActual1.precioProducto = this.getResources().getString(R.string.prec_postre1);
        productoActual1.imagenProducto = R.drawable.tira;
        arregloProductos.add(productoActual1);

        //Bebida 2
        ProductoPostres.Producto productoActual2 = new ProductoPostres.Producto();
        productoActual2.nombreProducto = this.getResources().getString(R.string.postre2);
        productoActual2.ingredientesProductos = this.getResources().getString(R.string.ing_postre2);
        productoActual2.precioProducto = this.getResources().getString(R.string.prec_postre2);
        productoActual2.imagenProducto = R.drawable.che;
        arregloProductos.add(productoActual2);

        //Bebida 3
        ProductoPostres.Producto productoActual3 = new ProductoPostres.Producto();
        productoActual3.nombreProducto = this.getResources().getString(R.string.postre3);
        productoActual3.ingredientesProductos = this.getResources().getString(R.string.ing_postre3);
        productoActual3.precioProducto = this.getResources().getString(R.string.prec_postre3);
        productoActual3.imagenProducto = R.drawable.fresas;
        arregloProductos.add(productoActual3);
    }

    public static class MyAdapter extends BaseAdapter {

        private Context myContexto;

        public MyAdapter(Context c) {
            myContexto = c;
        }

        @Override
        public int getCount() {
            return arregloProductos.size();
        }

        @Override
        public Object getItem(int arg) {
            return arregloProductos.get(arg);
        }

        @Override
        public long getItemId(int arg) {
            return 0;
        }

        @Override
        public View getView(int position, View vista, ViewGroup arg2) {
            View view = null;

            if (vista == null) {
                LayoutInflater inflater = (LayoutInflater) myContexto.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.activity_postre, null);
            } else {
                view = vista;
            }

            TextView nombreProducto = (TextView) view.findViewById(R.id.textViewnpostre);
            nombreProducto.setText(arregloProductos.get(position).nombreProducto);

            TextView ingredientesProducto = (TextView) view.findViewById(R.id.textViewipostre);
            ingredientesProducto.setText(arregloProductos.get(position).ingredientesProductos);
            ImageView ingProducto = (ImageView) view.findViewById(R.id.imageViewPostre);
            ingProducto.setImageDrawable(myContexto.getResources().getDrawable(arregloProductos.get(position).imagenProducto));

            TextView preciosProducto = (TextView) view.findViewById(R.id.textViewppostre);
            preciosProducto.setText(arregloProductos.get(position).precioProducto);

            return view;
        }
    }

}
