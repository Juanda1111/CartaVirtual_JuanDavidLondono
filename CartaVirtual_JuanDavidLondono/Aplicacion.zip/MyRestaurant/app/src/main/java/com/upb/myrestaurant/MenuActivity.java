package com.upb.myrestaurant;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

public class MenuActivity extends ListActivity {

    private String [] categoriasProductos = new String []{"Entradas", "Platos Fuertes", "Bebidas", "Postres"};

    private ListView listaCategorias = null;

    private ListAdapter adaptadorLista = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        listaCategorias = findViewById(android.R.id.list);

        adaptadorLista = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, categoriasProductos);

        listaCategorias.setAdapter(adaptadorLista);

    }

    @Override
    protected void onListItemClick (ListView lv, View v, int position, long id) {
        super.onListItemClick(lv, v, position, id);

        Intent i;

        switch (position) {
            case 0:
                i = new Intent(this, ProductoActivity.class); // Entradas
                break;
            case 1:
                i = new Intent(this, ProductoPlatos.class); // Platos Fuertes
                break;
            case 2:
                i = new Intent(this, ProductoBebida.class); // Bebidas
                break;
            case 3:
                i = new Intent(this, ProductoPostres.class); // Postres
                break;
            default:
                return;
        }

        startActivity(i);
    }



}